# 🇻🇳 HƯỚNG DẪN SỬ DỤNG BOT FREE FIRE TCP (SERVER VIỆT NAM - VIE)

Bản bot này đã được **gộp hoàn chỉnh** từ 2 mã nguồn:
1. **UNFAIR TCP BOT** (Bản bot TCP mạnh mẽ với hơn 70 lệnh, hệ thống giả lập phòng, lag, ghost, bio, world chat, badge, evo emotes...)
2. **bot ff tcp** (Hệ thống exploit auto-rejoin, friend list, phone/pincode lookup, quick emote attack, dynamic look changer, dance...)

Toàn bộ hệ thống đã được **tối ưu hóa 100% cho Server Việt Nam (`VIE` / `VN`)**:
- Sử dụng opcode packet chuẩn `0515` cho Server Việt Nam.
- Kết nối API `https://client.vn.freefiremobile.com` cho cập nhật tiểu sử (`/bio`), kết bạn (`/addfriend`).
- Tự động nhận diện `region = 'VIE'` và bypass mã bảo vệ khởi động.
- Hợp nhất cơ sở dữ liệu **385 Emote** đầy đủ nhất (`emotes.json`).

---

## 🚀 CÁCH KHỞI ĐỘNG BOT

### Cách 1: Chạy trực tiếp bằng file `run.bat` (Khuyên dùng)
- Nhấp đúp chuột vào file **`run.bat`** trong thư mục.
- File sẽ tự động cài đặt thư viện cần thiết và khởi động bot.

### Cách 2: Chạy qua Terminal / Command Prompt
```bash
pip install -r requirements.txt
python main.py
```

---

## ⚙️ CẤU HÌNH TÀI KHOẢN (SERVER VIE)

Mở file **`account.txt`** (hoặc `UNFAIR.txt` hoặc `config.json`) và điền thông tin tài khoản Bot:
```text
uid=UID_BOT_CỦA_BẠN,password=MAT_KHAU_OAUTH_HOAC_GUEST
```
Trong **`config.json`**:
```json
{
  "server_region": "VIE",
  "bot_uid": "UID_BOT",
  "bot_password": "MAT_KHAU_BOT",
  "admin_uid": "UID_ADMIN_CUA_BAN",
  "prefix": "/",
  "auto_reconnect": true
}
```

---

## 📋 DANH SÁCH TẤT CẢ CÁC LỆNH (HƠN 80+ LỆNH)

### 1. 👥 Quản Lý Tổ Đội & Mời Squad
| Lệnh | Mô tả |
|---|---|
| `/inv <UID>` | Gửi lời mời vào squad cho UID chỉ định |
| `/spm_inv <UID>` | Spam gửi lời mời liên tục vào squad |
| `/spam_group <UID>` | Mở squad kích thước lớn và spam mời |
| `/multijoin <TeamCode>` | Bot tham gia squad theo mã tổ đội |
| `/ghost <TeamCode>` | Tham gia squad ở chế độ Ghost (tàng hình) |
| `/xggst <TeamCode> <Tên>` | Tham gia squad dạng ghost với tên tuỳ chỉnh |
| `/exit` | Bot rời khỏi squad hiện tại |
| `/kick <UID>` / `/kkick` | Đá thành viên ra khỏi squad |

### 2. 🎭 Lệnh Emote & Ngoại Hình (Look / Bundle)
| Lệnh | Mô tả |
|---|---|
| `/e <ID_Emote>` | Bot thực hiện emote theo ID |
| `/em <Tên_Emote>` | Bot thực hiện emote theo tên (VD: `/em hello`, `/em lol`) |
| `/emote_list` hoặc `/emotes` | Xem danh sách các emote phổ biến |
| `/dance` | Thực hiện chuỗi emote nhảy múa liên tục |
| `/legendary_emote` | Bật chu kỳ emote Huyền Thoại |
| `/quick <TeamCode> <ID_Emote> <UID>` | Tấn công emote siêu tốc: Vào team -> bắn emote -> rời team |
| `/look <ID_Bundle>` | Đổi trang phục / ngoại hình bot sang bundle chỉ định |
| `/bundle <ID_Bundle>` | Đổi trang phục bundle |
| `/bundle_power <ID>` | Kích hoạt hiệu ứng trang phục đặc biệt |
| `/arr <ID_Animation>` | Kích hoạt hiệu ứng hoạt ảnh xuất hiện |
| `/magic` / `/offmagic` | Bật / tắt vòng lặp spam hiệu ứng ma thuật |
| `/mimic_on` / `/mimic_off` | Bật / tắt chế độ bắt chước emote của người trong team |
| `/block_emote <UID>` | Chặn emote từ người chơi chỉ định |
| `/unblock_emote <UID>` | Bỏ chặn emote |

### 3. 🛡️ Auto-Rejoin Anti-Kick Exploit (Độc quyền từ bản FF TCP)
| Lệnh | Mô tả |
|---|---|
| `/exploit_start` | Bật chế độ tự động vào lại team khi bị kick (Bất tử trong squad) |
| `/exploit_stop` | Tắt chế độ auto-rejoin exploit |
| `/exploit_status` | Kiểm tra trạng thái hoạt động của Exploit |

### 4. ⚔️ Phòng Tuỳ Chọn (Custom Room) & Trận Đấu
| Lệnh | Mô tả |
|---|---|
| `/createroom <Tên> <MậtKhẩu> <SốNgười>` | Tự động tạo phòng custom room |
| `/joinroom <ID_Phòng> <MậtKhẩu>` | Tự động tham gia phòng custom |
| `/room <ID_Phòng> <MậtKhẩu>` | Spam tham gia phòng custom |
| `/room_msg <NộiDung>` | Gửi tin nhắn vào phòng |
| `/start` / `/start1` | Tự động spam bắt đầu trận đấu |
| `/stop1` | Dừng spam bắt đầu trận |
| `/train` | Tự động tham gia khu luyện tập (Training Room) |

### 5. ⚡ Lag & Đóng Băng (Lag / Freeze)
| Lệnh | Mô tả |
|---|---|
| `/lagc <TeamCode>` | Gây lag và làm nghẽn kết nối tổ đội |
| `/stop_lagc` | Dừng gây lag tổ đội |
| `/lagx` | Gây lag squad nâng cao |
| `/freeze <UID>` | Đóng băng client người chơi mục tiêu |
| `/rmlag` | Xoá lag và phục hồi trạng thái bình thường |

### 6. 📊 Thông Tin Người Chơi & Mạng Xã Hội
| Lệnh | Mô tả |
|---|---|
| `/infox <UID>` | Xem chi tiết thông tin acc người chơi (Rank, Level, Like, Bio, Clan...) |
| `/duo <UID>` | Kiểm tra thông tin bạn đồng hành (Duo Partner) |
| `/bio <Nội dung tiểu sử>` | Thay đổi chữ ký/tiểu sử trực tiếp trên Server Việt Nam |
| `/like <UID>` | Tăng lượt like cho trang cá nhân người chơi |
| `/addfriend <UID>` | Gửi lời mời kết bạn trực tiếp trên Server Việt Nam |
| `/visit <UID>` | Tăng lượt xem/lượt ghé thăm hồ sơ |
| `/check <UID>` | Kiểm tra trạng thái tài khoản (Ban/Active) |
| `/friend_list` | Lấy danh sách bạn bè của bot |

### 7. 🌐 Chat Thế Giới & Tương Tác
| Lệnh | Mô tả |
|---|---|
| `/world <NộiDung>` | Gửi tin nhắn lên kênh chat Thế Giới (World Chat VIE) |
| `/worlds` | Spam tin nhắn lên kênh thế giới |
| `/world_fast` | Spam chat thế giới tốc độ cao |
| `/tagx <NộiDung>` | Tag và spam tin nhắn trong squad |
| `/xspam <NộiDung> <SốLần>` | Spam tin nhắn theo số lần tuỳ chọn |

### 8. 🏷️ Huy Hiệu, Danh Hiệu & Mini Game
| Lệnh | Mô tả |
|---|---|
| `/s1` đến `/s8` | Gửi chuỗi yêu cầu huy hiệu và gói quà tặng |
| `/title` / `/title_sm` | Đổi danh hiệu hiển thị trên đầu bot |
| `/coin` | Trò chơi tung đồng xu (Ngửa/Sấp) |
| `/dice` | Trò chơi lắc xúc xắc (1-6) |
| `/random` | Lấy số may mắn ngẫu nhiên |
| `/jwt` | Lấy token JWT mới từ tài khoản Guest |
| `/status` | Kiểm tra trạng thái máy chủ và kết nối của Bot |
| `!<Câu hỏi>` | Trò chuyện cùng AI thông minh |
| `.ai on` / `.ai off` | Bật / tắt chế độ tự động trả lời bằng AI |
