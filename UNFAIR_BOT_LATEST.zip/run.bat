@echo off
chcp 65001 >nul
title Free Fire TCP Bot - Server Viet Nam [VIE]
echo ========================================================
echo   FREE FIRE TCP MASTER BOT - SERVER VIET NAM (VIE)
echo ========================================================
echo Dang kiem tra thu vien Python...
python -m pip install -r requirements.txt --quiet
echo.
echo Dang khoi dong Bot Free Fire Server VIE...
echo.
python main.py
pause
